void matrix_multiply(double **c, double **a, double **b, int a_height, int b_height, int b_width);
void fast_matrix_multiply(double **c, double **a, double **b, int a_height, int b_height, int b_width);
void parallel_matrix_multiply(double **c, double **a, double **b, int a_height, int b_height, int b_width);
